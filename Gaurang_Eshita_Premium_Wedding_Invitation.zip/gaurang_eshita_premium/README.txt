GAURANG & ESHITA — WEDDING INVITATION WEBSITE

HOW TO PREVIEW
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or another modern browser.

HOW TO HOST FREE ON NETLIFY
1. Go to https://app.netlify.com/drop
2. Drag the extracted folder (the folder containing index.html) into the page.
3. Netlify will publish it and provide a shareable URL.

CONTENTS
- index.html: responsive interactive invitation website
- shiva_parvati_invitation_art.png: original decorative Shiva-Parvati wedding artwork

DATES INCLUDED
Engagement: 29 November 2026
Wedding: 4 December 2026
Reception: 5 December 2026

Optional music: add a licensed music file named music.mp3 beside index.html. The music button will then play/pause it. Music is not included in this ZIP.

Note: This is a polished custom design inspired by your reference screenshots, not the original site's source code.
